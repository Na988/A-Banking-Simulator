public class Auditor1 implements Runnable {

    String auditOut="**********************************************************************************************" +
            "***********************************";
    int Auditor1Count=0;


    Auditor1(){

    }

    @Override
    public void run() {
        while (true){

            try {
                Thread.sleep((long)(Math. random() * 5000));
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            Control.lock.lock();
            try {

                Auditor1Count=Control.tranNum-Auditor1Count;
                showOut(Auditor1Count);

            } finally {
                Control.lock.unlock();
            }

        }

    }
    void showOut(int aCount){

        String tranNum="Number of transactions since last audit is: "+aCount;

        String balance="TREASURY DEPT AUDITOR FINDS ACCOUNT BALANCE TO BE: $"+Control.Balance;

        System.out.printf("%s\n",auditOut);

        System.out.printf("        %-25s\t\t%-25s \n",balance ,tranNum);

        System.out.printf("\n%s\n",auditOut);




    }
}
